import { type ChangeEvent, type DragEvent, type ReactNode, useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useCreateVirtualTryOn, useHealthCheck } from '@workspace/api-client-react';
import { ArrowRight, Check, ChevronDown, Download, ImagePlus, RefreshCw, Sparkles, TriangleAlert, Upload, X } from 'lucide-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();
const MAX_FILE_SIZE = 12 * 1024 * 1024;
type SlotKind = 'person' | 'clothing';
type UploadState = { file: File | null; preview: string; error: string };

const initialUpload: UploadState = { file: null, preview: '', error: '' };

function fileToDataUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error('We could not read that image.'));
    reader.readAsDataURL(file);
  });
}

function UploadCard({
  kind,
  state,
  onSelect,
  onClear,
}: {
  kind: SlotKind;
  state: UploadState;
  onSelect: (file: File) => void;
  onClear: () => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  const title = kind === 'person' ? 'Your photo' : 'The piece';
  const eyebrow = kind === 'person' ? '01 / PERSON' : '02 / CLOTHING';
  const helper = kind === 'person' ? 'A clear, full-body photo works best' : 'Front-facing, on a plain background';

  const handleDrop = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setDragging(false);
    const file = event.dataTransfer.files?.[0];
    if (file) onSelect(file);
  };

  const handleInput = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) onSelect(file);
    event.target.value = '';
  };

  return (
    <div
      className={`upload-card ${state.preview ? 'has-image' : ''} ${state.error ? 'error' : ''} ${dragging ? 'dragging' : ''}`}
      onDragOver={(event) => { event.preventDefault(); setDragging(true); }}
      onDragLeave={() => setDragging(false)}
      onDrop={handleDrop}
      data-testid={`upload-card-${kind}`}
    >
      <input ref={inputRef} id={`${kind}-image`} type="file" accept="image/jpeg,image/png,image/webp" onChange={handleInput} data-testid={`input-${kind}-image`} />
      {state.preview ? (
        <>
          <img src={state.preview} alt={`${title} preview`} className="preview-image" data-testid={`img-preview-${kind}`} />
          <div className="preview-wash" />
          <div className="absolute inset-x-0 bottom-0 z-10 flex items-end justify-between p-4 text-left text-[hsl(var(--card))]">
            <div className="min-w-0">
              <p className="truncate text-sm font-semibold">{state.file?.name}</p>
              <p className="mt-1 font-mono text-[10px] uppercase tracking-[.16em] text-[hsl(var(--card)/.7)]">Ready to pair</p>
            </div>
            <button type="button" onClick={onClear} className="ml-3 flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-[hsl(var(--card)/.35)] bg-[hsl(var(--foreground)/.24)] transition hover:bg-[hsl(var(--foreground)/.45)]" aria-label={`Remove ${kind} image`} data-testid={`button-clear-${kind}`}>
              <X size={16} />
            </button>
          </div>
        </>
      ) : (
        <label htmlFor={`${kind}-image`}>
          <span className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-[hsl(var(--secondary)/.45)] text-[hsl(var(--primary))] shadow-sm">
            {kind === 'person' ? <ImagePlus size={25} strokeWidth={1.7} /> : <Upload size={24} strokeWidth={1.7} />}
          </span>
          <span className="font-mono text-[10px] font-medium tracking-[.2em] text-[hsl(var(--primary))]">{eyebrow}</span>
          <span className="mt-2 font-serif text-[1.8rem] leading-none text-[hsl(var(--foreground))]">{title}</span>
          <span className="mt-3 max-w-[15rem] text-xs leading-relaxed text-[hsl(var(--muted-foreground))]">{dragging ? 'Drop it here — we’ll take it from here' : helper}</span>
          <span className="mt-5 flex items-center gap-1.5 text-xs font-semibold text-[hsl(var(--accent))]">Choose image <ArrowRight size={13} /></span>
        </label>
      )}
      {state.error && <p className="absolute bottom-2 left-4 right-4 z-20 rounded-lg bg-[hsl(var(--destructive)/.92)] px-2.5 py-1.5 text-center text-[11px] font-medium text-[hsl(var(--destructive-foreground))]" role="alert" data-testid={`error-${kind}-image`}>{state.error}</p>}
    </div>
  );
}

function Header() {
  const { data: health, isError } = useHealthCheck({ query: { queryKey: ['/api/healthz'], staleTime: 30_000 } });
  const statusLabel = isError ? 'Private mode' : health?.status === 'ok' ? 'Ready when you are' : 'Fitting room open';
  return (
    <header className="mx-auto flex w-full max-w-6xl items-center justify-between px-5 py-5 md:px-8 md:py-7">
      <a href="/" className="flex items-center gap-2.5" data-testid="link-home">
        <span className="flex h-9 w-9 items-center justify-center rounded-[13px] bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))] shadow-sm"><Sparkles size={18} fill="currentColor" /></span>
        <span className="font-serif text-[1.6rem] leading-none tracking-tight">fitting room<span className="text-[hsl(var(--primary))]">.</span></span>
      </a>
      <div className="flex items-center gap-2 text-right">
        <span className={`h-2 w-2 rounded-full ${isError ? 'bg-[hsl(var(--secondary))]' : 'bg-[hsl(var(--accent))]'} animate-breathe`} />
        <span className="font-mono text-[9px] uppercase tracking-[.16em] text-[hsl(var(--muted-foreground))]">{statusLabel}</span>
      </div>
    </header>
  );
}

function ProgressPanel() {
  const [progress, setProgress] = useState(56);
  useMemo(() => {
    const timer = window.setInterval(() => setProgress((current) => current >= 89 ? current : current + 5), 900);
    return () => window.clearInterval(timer);
  }, []);
  const steps = [
    { label: 'Reading your photos', done: progress >= 32 },
    { label: 'Fitting the silhouette', done: progress >= 65 },
    { label: 'Finishing the details', done: progress >= 92 },
  ];
  return (
    <section className="animate-rise rounded-[1.45rem] border border-[hsl(var(--border))] bg-[hsl(var(--card)/.82)] p-5 shadow-[var(--shadow-soft)] md:p-7" aria-live="polite" data-testid="panel-progress">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="font-mono text-[10px] uppercase tracking-[.18em] text-[hsl(var(--primary))]">Your fitting room is working</p>
          <h2 className="mt-2 font-serif text-3xl leading-none">A little patience.</h2>
        </div>
        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[hsl(var(--secondary)/.42)] text-[hsl(var(--primary))]"><Sparkles size={20} className="animate-breathe" /></div>
      </div>
      <div className="mt-7 progress-track"><div className="progress-fill" style={{ width: `${progress}%` }} /></div>
      <div className="mt-2 flex justify-between font-mono text-[10px] uppercase tracking-[.12em] text-[hsl(var(--muted-foreground))]"><span>Styling in progress</span><span>{progress}%</span></div>
      <div className="mt-7 space-y-4">
        {steps.map((step) => <div key={step.label} className="flex items-center gap-3 text-sm"><span className={`flex h-6 w-6 items-center justify-center rounded-full ${step.done ? 'bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))]' : 'border border-[hsl(var(--border))] text-transparent'}`}><Check size={13} strokeWidth={3} /></span><span className={step.done ? 'text-[hsl(var(--foreground))]' : 'text-[hsl(var(--muted-foreground))]'}>{step.label}</span></div>)}
      </div>
      <p className="mt-7 border-t border-[hsl(var(--border))] pt-4 text-xs leading-relaxed text-[hsl(var(--muted-foreground))]">You can leave this tab open. Your images are used only to make this fitting.</p>
    </section>
  );
}

function ResultPanel({ imageUrl, onStartOver }: { imageUrl: string; onStartOver: () => void }) {
  return (
    <section className="animate-reveal" data-testid="panel-result">
      <div className="mb-5 flex items-end justify-between gap-4">
        <div><p className="font-mono text-[10px] uppercase tracking-[.18em] text-[hsl(var(--accent))]">The reveal</p><h2 className="mt-2 font-serif text-4xl leading-none md:text-5xl">That’s the one.</h2></div>
        <span className="hidden rounded-full bg-[hsl(var(--secondary)/.45)] px-3 py-1.5 font-mono text-[9px] uppercase tracking-[.14em] text-[hsl(var(--foreground))] sm:block">Made for you</span>
      </div>
      <div className="overflow-hidden rounded-[1.6rem] border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-2 shadow-[var(--shadow-lift)]">
        <img src={imageUrl} alt="Your virtual try-on result" className="max-h-[65vh] min-h-[360px] w-full rounded-[1.15rem] object-cover md:max-h-[700px]" data-testid="img-result" />
      </div>
      <div className="mt-4 flex flex-col gap-3 sm:flex-row">
        <a href={imageUrl} download="fitting-room-result.png" className="flex h-12 flex-1 items-center justify-center gap-2 rounded-full bg-[hsl(var(--foreground))] text-sm font-semibold text-[hsl(var(--card))] transition hover:-translate-y-0.5 hover:bg-[hsl(var(--accent))]" data-testid="button-download-result"><Download size={16} /> Save this look</a>
        <button type="button" onClick={onStartOver} className="flex h-12 flex-1 items-center justify-center gap-2 rounded-full border border-[hsl(var(--border))] bg-[hsl(var(--card)/.65)] text-sm font-semibold transition hover:-translate-y-0.5 hover:border-[hsl(var(--primary)/.6)]" data-testid="button-start-over"><RefreshCw size={16} /> Try another look</button>
      </div>
    </section>
  );
}

function ErrorPanel({ message, onRetry }: { message: string; onRetry: () => void }) {
  return <section className="animate-rise rounded-[1.45rem] border border-[hsl(var(--destructive)/.35)] bg-[hsl(var(--destructive)/.07)] p-6 text-center md:p-9" role="alert" data-testid="panel-generation-error"><span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-[hsl(var(--destructive)/.13)] text-[hsl(var(--destructive))]"><TriangleAlert size={25} /></span><p className="mt-5 font-mono text-[10px] uppercase tracking-[.18em] text-[hsl(var(--destructive))]">The fitting room needs a reset</p><h2 className="mt-2 font-serif text-3xl">We couldn’t make that look.</h2><p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-[hsl(var(--muted-foreground))]">{message || 'Something interrupted the try-on. Your photos are still here — give it another go.'}</p><button type="button" onClick={onRetry} className="mt-6 inline-flex h-11 items-center gap-2 rounded-full bg-[hsl(var(--foreground))] px-5 text-sm font-semibold text-[hsl(var(--card))] transition hover:-translate-y-0.5" data-testid="button-retry-generation"><RefreshCw size={15} /> Try again</button></section>;
}

function Home() {
  const [person, setPerson] = useState<UploadState>(initialUpload);
  const [clothing, setClothing] = useState<UploadState>(initialUpload);
  const [result, setResult] = useState('');
  const [attempted, setAttempted] = useState(false);
  const mutation = useCreateVirtualTryOn();

  const processFile = async (file: File, kind: SlotKind) => {
    const setState = kind === 'person' ? setPerson : setClothing;
    if (!file.type.startsWith('image/')) {
      setState((previous) => ({ ...previous, error: 'Please choose a JPG, PNG, or WEBP image.' }));
      return;
    }
    if (file.size > MAX_FILE_SIZE) {
      setState((previous) => ({ ...previous, error: 'That image is over 12 MB. A smaller one will work beautifully.' }));
      return;
    }
    try {
      const preview = await fileToDataUrl(file);
      setState({ file, preview, error: '' });
      setResult('');
      setAttempted(false);
    } catch {
      setState((previous) => ({ ...previous, error: 'We could not read that image. Try another file.' }));
    }
  };

  const canSubmit = Boolean(person.preview && clothing.preview) && !mutation.isPending;
  const submit = () => {
    setAttempted(true);
    if (!person.preview || !clothing.preview) return;
    setResult('');
    mutation.mutate({ data: { person_image_url: person.preview, clothing_image_url: clothing.preview } }, {
      onSuccess: (data) => setResult(data.image_url),
    });
  };
  const startOver = () => {
    setPerson(initialUpload);
    setClothing(initialUpload);
    setResult('');
    setAttempted(false);
    mutation.reset();
  };
  const submitLabel = mutation.isPending ? 'Making your look…' : '✨ Try On';

  return (
    <div className="grain min-h-[100dvh] overflow-x-hidden">
      <Header />
      <main className="mx-auto w-full max-w-6xl px-5 pb-16 md:px-8 md:pb-24">
        <section className="grid items-end gap-8 pb-12 pt-8 md:grid-cols-[1.05fr_.95fr] md:gap-16 md:pb-20 md:pt-16">
          <div className="animate-rise">
            <p className="font-mono text-[10px] uppercase tracking-[.22em] text-[hsl(var(--primary))]">A private fitting room, wherever you are</p>
            <h1 className="mt-5 max-w-xl font-serif text-[4.25rem] leading-[.83] tracking-[-.045em] text-[hsl(var(--foreground))] sm:text-[5.8rem] md:text-[6.8rem]">See it<br /><em className="text-[hsl(var(--primary))]">on you.</em></h1>
            <p className="mt-7 max-w-md text-[15px] leading-7 text-[hsl(var(--muted-foreground))]">A quick, private preview before you commit. Bring a photo of yourself, bring the piece you’re considering — we’ll bring them together.</p>
            <div className="mt-7 flex items-center gap-3 text-xs text-[hsl(var(--muted-foreground))]"><span className="flex -space-x-1.5"><span className="h-7 w-7 rounded-full border-2 border-[hsl(var(--background))] bg-[hsl(var(--secondary))]" /><span className="h-7 w-7 rounded-full border-2 border-[hsl(var(--background))] bg-[hsl(var(--accent)/.75)]" /><span className="h-7 w-7 rounded-full border-2 border-[hsl(var(--background))] bg-[hsl(var(--primary)/.75)]" /></span><span>Made for the maybe-buyers.</span></div>
          </div>
          <div className="relative hidden min-h-[280px] items-center justify-center md:flex">
            <div className="absolute h-64 w-64 rounded-full border border-[hsl(var(--primary)/.18)]" />
            <div className="absolute h-48 w-48 rounded-full border border-dashed border-[hsl(var(--accent)/.25)]" />
            <div className="relative rotate-[-7deg] rounded-[1.4rem] border border-[hsl(var(--border))] bg-[hsl(var(--card)/.86)] p-4 shadow-[var(--shadow-soft)]"><div className="flex h-48 w-36 items-end justify-center overflow-hidden rounded-[1rem] bg-[hsl(var(--secondary)/.34)]"><span className="mb-10 h-20 w-20 rounded-[48%] bg-[hsl(var(--primary)/.62)]" /><span className="absolute mt-36 h-20 w-32 rounded-t-[55%] bg-[hsl(var(--accent)/.72)]" /></div><p className="mt-3 font-mono text-[9px] uppercase tracking-[.17em] text-[hsl(var(--muted-foreground))]">your silhouette</p></div>
            <div className="absolute bottom-5 right-8 rotate-[8deg] rounded-[1.4rem] border border-[hsl(var(--border))] bg-[hsl(var(--card)/.9)] p-3 shadow-[var(--shadow-soft)]"><div className="flex h-32 w-24 items-center justify-center rounded-[1rem] bg-[hsl(var(--primary)/.12)]"><div className="h-24 w-14 rounded-[48%_48%_35%_35%] bg-[hsl(var(--primary)/.72)]" /></div><p className="mt-2 font-mono text-[9px] uppercase tracking-[.17em] text-[hsl(var(--muted-foreground))]">the piece</p></div>
            <span className="absolute right-8 top-2 font-serif text-xl italic text-[hsl(var(--accent))]">just curious?</span>
          </div>
        </section>

        <section className="border-t border-[hsl(var(--border))] pt-8 md:pt-10" data-testid="section-upload-workflow">
          <div className="mb-6 flex flex-col justify-between gap-3 sm:flex-row sm:items-end"><div><p className="font-mono text-[10px] uppercase tracking-[.18em] text-[hsl(var(--muted-foreground))]">Two images. One maybe.</p><h2 className="mt-2 font-serif text-3xl md:text-4xl">Start with the essentials.</h2></div><p className="max-w-xs text-left text-xs leading-relaxed text-[hsl(var(--muted-foreground))] sm:text-right">Your images stay yours. We use them to create this preview, then let them go.</p></div>
          {mutation.isPending ? <ProgressPanel /> : result ? <ResultPanel imageUrl={result} onStartOver={startOver} /> : mutation.isError ? <ErrorPanel message={String((mutation.error as { error?: string })?.error || '')} onRetry={submit} /> : <><div className="grid gap-4 md:grid-cols-2"><UploadCard kind="person" state={person} onSelect={(file) => void processFile(file, 'person')} onClear={() => setPerson(initialUpload)} /><UploadCard kind="clothing" state={clothing} onSelect={(file) => void processFile(file, 'clothing')} onClear={() => setClothing(initialUpload)} /></div>{attempted && !canSubmit && <p className="mt-4 flex items-center gap-2 text-xs font-medium text-[hsl(var(--destructive))]" role="alert" data-testid="error-missing-images"><TriangleAlert size={14} /> Add both images to open your fitting room.</p>}<button type="button" disabled={!canSubmit} onClick={submit} className="group mt-5 flex h-14 w-full items-center justify-center gap-3 rounded-full bg-[hsl(var(--primary))] text-[15px] font-bold text-[hsl(var(--primary-foreground))] shadow-[0_10px_25px_hsl(var(--primary)/.2)] transition hover:-translate-y-0.5 hover:shadow-[0_14px_30px_hsl(var(--primary)/.28)] disabled:cursor-not-allowed disabled:opacity-45 disabled:shadow-none" data-testid="button-submit-try-on">{submitLabel}<ArrowRight size={18} className="transition-transform group-hover:translate-x-1" /></button></>}
        </section>

        <footer className="mt-16 flex flex-col gap-4 border-t border-[hsl(var(--border))] pt-5 text-[11px] text-[hsl(var(--muted-foreground))] sm:flex-row sm:items-center sm:justify-between"><span className="font-mono uppercase tracking-[.16em]">fitting room / 001</span><span className="flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-[hsl(var(--accent))]" /> No accounts. No judgment. Just a look.</span></footer>
      </main>
    </div>
  );
}

function Router() {
  return <RoutedErrorBoundary><Switch><Route path="/" component={Home} /><Route component={NotFound} /></Switch></RoutedErrorBoundary>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;