import { Router, type IRouter } from "express";

const router: IRouter = Router();

router.post("/virtual-try-on", async (req, res) => {
  try {
    const { person_image_url, clothing_image_url } = req.body;

    if (!person_image_url || !clothing_image_url) {
      return res.status(400).json({
        error: "person_image_url and clothing_image_url are required",
      });
    }

    const falKey = process.env.FAL_KEY;

    if (!falKey) {
      return res.status(500).json({
        error: "FAL_KEY is not configured",
      });
    }

    const submitResponse = await fetch(
      "https://queue.fal.run/fal-ai/image-apps-v2/virtual-try-on",
      {
        method: "POST",
        headers: {
          Authorization: `Key ${falKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          person_image_url,
          clothing_image_url,
        }),
      }
    );

    if (!submitResponse.ok) {
      const errorText = await submitResponse.text();

      console.error(
        "fal.ai submit error:",
        submitResponse.status,
        errorText
      );

      return res.status(502).json({
        error: "fal.ai virtual try-on failed",
        status: submitResponse.status,
      });
    }

    const submitData = await submitResponse.json() as {
      request_id?: string;
    };

    const requestId = submitData.request_id;

    if (!requestId) {
      return res.status(502).json({
        error: "fal.ai did not return request_id",
      });
    }

    for (let i = 0; i < 60; i++) {
      await new Promise((resolve) =>
        setTimeout(resolve, 2000)
      );

      const statusResponse = await fetch(
        `https://queue.fal.run/fal-ai/image-apps-v2/virtual-try-on/requests/${requestId}/status`,
        {
          headers: {
            Authorization: `Key ${falKey}`,
          },
        }
      );

      if (!statusResponse.ok) {
        continue;
      }

      const statusData = await statusResponse.json() as {
        status?: string;
      };

      if (statusData.status === "COMPLETED") {
        const resultResponse = await fetch(
          `https://queue.fal.run/fal-ai/image-apps-v2/virtual-try-on/requests/${requestId}`,
          {
            headers: {
              Authorization: `Key ${falKey}`,
            },
          }
        );

        const result = await resultResponse.json() as {
          images?: Array<{
            url?: string;
          }>;
        };

        const imageUrl = result.images?.[0]?.url;

        if (!imageUrl) {
          return res.status(502).json({
            error: "No output image returned by fal.ai",
          });
        }

        return res.json({
          image_url: imageUrl,
        });
      }
    }

    return res.status(504).json({
      error: "fal.ai virtual try-on timed out",
    });
  } catch (error) {
    console.error("Virtual try-on error:", error);

    return res.status(500).json({
      error: "Internal server error",
    });
  }
});

export default router;